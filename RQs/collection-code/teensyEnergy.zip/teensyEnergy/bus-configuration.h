// Working version Sep 11 2025 premier version for Ethernet teensy 
// WORKING VERSION CIRCA MAY 27 2025
// contains infrastructure for defining INAs for a 3 busses for a ttoal of 48
//still works as of august 1st 2025, havent changed much
//i should refactor this sometimes
// aug 18 begin work on refactoring

//Define I2C-Bus Clock Frequency
//#define BUS_CLOCK_FREQUENCY         400000
//#define BUS_CLOCK_FREQUENCY         100000
//#define BUS_CLOCK_FREQUENCY            800000
#define BUS_CLOCK_FREQUENCY           1000000          
//#define BUS_CLOCK_FREQUENCY           5000000
//#define BUS_CLOCK_FREQUENCY         2940000

//Define INA226-Registers
#define CONFIGURATION_REGISTER      0x00
#define SHUNT_VOLTAGE_REGISTER      0x01
#define BUS_VOLTAGE_REGISTER        0x02
#define POWER_REGISTER              0x03
#define CURRENT_REGISTER            0x04
#define CALIBRATION_REGISTER        0x05
#define MASK_ENABLE_REGISTER        0x06
#define ALERT_LIMIT_REGISTER        0x07
#define MANUFACTURER_ID_REGISTER    0xFE
#define DIE_ID_REGISTER             0xFF

//Define Configuration
//0x4007 -> ConversionTime: 140 microseconds, Averaging: 1
//#define CONFIGURATION_MSB           0x40
//#define CONFIGURATION_LSB           0x07
//0x4007 -> ConversionTime: 140 microseconds, Averaging: 4
//#define CONFIGURATION_MSB           0x42
//#define CONFIGURATION_LSB           0x07

//0x0007 -> ConversionTime: 140 microseconds, Averaging: 1 -- checked the manual!!
#define CONFIGURATION_MSB           0x00
#define CONFIGURATION_LSB           0x07

//Define Addresses of measured components
#define mobo_1                   0x40  //64
#define mobo_2                   0x41  //65
#define CPU_1                     0x42  //66
//#define SSD_12V                     0x43  //67
#define mobo_3                   0x44  //68
#define mobo_4                   0x45  //69


#define NO_DEVICE 0x00

//contain info for each sensor. i2c address conflicts are allowed sofar as they are on different bus!
struct SensorConfig {
  char id;                //readable id
  String description; 
  int i2c_address = 0x00; //i2c address 
  int config = 0x0007; //speed and averaging config
  int cal = 0x0000; // calibration register for gain // cal format: 0x[msb for ina226][lsb for ina226] This took me so long to figure out on god Aug25
  bool is_online = false; //online, default false
  int bus = 0;
  float rshunt = 0.01;
};

#define CONFIG 0x0007 //regular
//#define CONFIG 0x0E07 //averaging per 1024 observations
static SensorConfig sensors [] = {    //Real config
  {'A', "mobo_1", 0x40, CONFIG, 0x045F, false, 1, 0.01},
  {'B', "mobo_2", 0x41, CONFIG, 0x045F, false, 1, 0.01},
  {'C', "mobo_3", 0x44, CONFIG, 0x045F, false, 1, 0.01},
  {'D', "mobo_4", 0x45, CONFIG, 0x045F, false, 1, 0.01},
  
  {'H', "mobo_5", 0x40, CONFIG, 0x045F, false, 0, 0.01},
  {'I', "mobo_6", 0x41, CONFIG, 0x045F, false, 0, 0.01},
  {'J', "mobo_7", 0x44, CONFIG, 0x045F, false, 0, 0.01},
  {'K', "mobo_8", 0x45, CONFIG, 0x045F, false, 0, 0.01},

  {'Y', "cpu_2", 0x43, CONFIG, 0x0347, false, 0, 0.01},
  {'Z', "cpu_1", 0x42, CONFIG, 0x0347, false, 0, 0.01},

  {'O', "mobo_9", 0x40, CONFIG, 0x045F, false, 2, 0.01},
  {'P', "mobo_10", 0x41, CONFIG, 0x045F, false, 2, 0.01},
  {'Q', "mobo_11", 0x44, CONFIG, 0x045F, false, 2, 0.01},  
  {'R', "mobo_12", 0x45, CONFIG, 0x045F, false, 2, 0.01},

  {'U', "stck_1", 0x46, CONFIG, 0x19AA, false, 2, 0.0016666}, 
  {'V', "stck_2", 0x47, CONFIG, 0x19AA, false, 2, 0.0016666}

  // {'G', "test40w", 0x40, CONFIG, 0x045F, false, 0, 0.01}
};
// static SensorConfig sensors [] = {      //test config
//   {'Z', "testing 16", 0x43, CONFIG, 0x045F, false, 0, 0.01}
// };


//everything below here is almost definitly useless
// but im too corwardly to remove 

int INAs0[16] = { mobo_1,
                 mobo_2,
                 mobo_3,
                 mobo_4,
                 CPU_1,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE
               };

// calibration speeed and averaging
int CONF0[16] = {
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007
  };
               

//Define Calibration for each INA226
int CALs0[16] = { 0x1400,
                 0x0200,
                 0x0200,
                 0x0200,
                 0x0066,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE
               };


//const char *COMPONENTNAMES0[6] = { "CPU_12V_1",
                                   //"CPU_12V_2",
                                   //"SSD_5V",
                                   //"SSD_12V",
                                   //"MOBO_5V_1",
                                   //"MOBO_5V_2",
                                 //};

char COMPONENTS0[16] = { 'A',
                               'B',
                               'C',
                               'D',
                               'Z',
                               NO_DEVICE,     
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE
                             };

bool ONLINE0[16] = { 0,
                    0,
                    0,
                    0,
                    0,
                    0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0
                  };



//

#pragma region BUS1Adresses
#define mobo_5                 0x40  //64
#define mobo_6                0x41  //65
#define mobo_7                 0x44  //66
#define mobo_8                 0x45  //67
#define CPU_2                  0x43
// #define MOBO_12V_1                  0x44  //68
// #define MOBO_12V_2                  0x45  //69
#pragma endregion

int INAs1[16] = { mobo_5,
                 mobo_6,
                 mobo_7,
                 mobo_8,
                 CPU_2,
                 NO_DEVICE,
                 
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE
               };

// calibration speeed and averaging
int CONF1[16] = {
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007
  };

//Define Calibration for each INA226
int CALs1[16] = { 0x0200,
                 0x0200,
                 0x0200,
                 0x0200,
                 0x0066,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE
               };



char COMPONENTS1[16] = { 'H',
                               'I',
                               'J',
                               'K',
                               'Y',
                               NO_DEVICE,        
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE
                             };


bool ONLINE1[16] = { 0,
                    0,
                    0,
                    0,
                    0,
                    0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0
                  };




//BUS 2 Adresses
#pragma region BUS2Adresses
#define mobo_9                 0x40  //64
#define mobo_10                0x41  //65
#define mobo_11                 0x44  //66
#define mobo_12                 0x45  //67
#pragma endregion

int INAs2[16] = { mobo_9, mobo_10, mobo_11,
                 mobo_12, NO_DEVICE, NO_DEVICE,
                 NO_DEVICE, NO_DEVICE, NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE
               };

// calibration speeed and averaging
int CONF2[16] = {
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007,
    0x0007
  };

//Define Calibration for each INA226
int CALs2[16] = { 0x0200,
                 0x0200,
                 0x0200,
                 0x0200,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE,
                 NO_DEVICE
               };

char COMPONENTS2[16] = { 'O', 'P', 'Q', 
                        'R', NO_DEVICE, NO_DEVICE,        
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE,
                               NO_DEVICE
                             };


bool ONLINE2[16] = { 0,
                    0,
                    0,
                    0,
                    0,
                    0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0,
                   0
                  };                  
