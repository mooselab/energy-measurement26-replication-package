// The goal here is to implement a sensor polling and data sender server using TCP on teensy 4.1
// Using GPT1 clock times as relative time. 

// TCP portion based on the following example file:
// a copy of the original working timestamp bouncing file is backed up in cloud 
// SPDX-FileCopyrightText: (c) 2021-2023 Shawn Silverman <shawn@pobox.com>
// SPDX-License-Identifier: AGPL-3.0-or-later

// ServerWithListeners demonstrates how to use listeners to start and
// stop services. Do some testing, then connect the Teensy to an
// entirely different network by moving the Ethernet connection and
// the program will still work.
//
// This also demonstrates:
// 1. Using a link state listener,
// 2. Setting a static IP if desired,
// 3. Managing connections and attaching state to each connection,
// 4. How to use `printf`,
// 5. Very rudimentary HTTP server behaviour,
// 6. Client timeouts, and
// 7. Use of a half closed connection.

#pragma region BareCTFDependencies
#include "barectf.h"
#pragma endregion

#pragma region TimeDependencies 
#pragma endregion 

#pragma region CTFdependencies
#include "CTF.h"
#pragma endregion //endregion CTF dependencies

#pragma region TCPdependencies 
#include <algorithm>
#include <cstdio>
#include <utility>
#include <vector>

#include <QNEthernet.h>

#include <map>
#include <string>
using namespace qindesign::network;
#pragma endregion

#pragma region PowerFetcherdependencies 
#include <Wire.h>
#include "bus-configuration.h"
#include <array>
#include <algorithm>
#pragma endregion //end powerfetcher dependencies

#pragma region TimeVariables 
// put anything realated ti time here in here.
#pragma endregion 

#pragma region bareCTFVariables
struct barectf_default_ctx ctx; 
std::array<uint8_t, 512> barectf_buffer; 
struct barectf_platform_callbacks cbs; 
#pragma endregion

#pragma region SpecialVariables //like buffers, things that need to be at the top. also include global time keeping stuff
const int BUFFER_MAX = 512;
std::array<uint8_t, BUFFER_MAX> buffer;
int bufferOffset = 0;

volatile uint64_t time_gpt1_tick = 0; //global gpt-1 tick, for looping only

// We are going to try adding another timer 
  // tier 1 micros timer (local time)
const uint64_t NS_PER_OVERFLOW = 4294967296ULL * 1000ULL;
uint32_t micros_times_overflown = 0;
uint32_t micros_last_update_us;
  // tier 2 host timer (workload time)
uint64_t host_offset_ns = 0; // assumption is that the host time, since boot should always > teensy time since boot.
                            // if we suspect the quality of a sync is bad, we will simply use the old offset until the next good one arrives.
// end of timer circa 2026 jan 26

bool host_driven = false; //if flag is set, only start logging when time provider connects. //im not sure if i ever finished this feature

#pragma endregion //end special variables 

#pragma region CTFdefs  //ctf buffer and defs live here
//Structs not to be serialized: send each byte array field of structs in order of appearance for correct CTF. 
// for the two constant packet headers, only serialize byte arrays.
struct Ctf_packet_header_bytes {
  static constexpr uint32_t length = 24;
  static constexpr uint8_t MAGIC[4]= {0xC1, 0x1F, 0xFC, 0xC1};
  static constexpr uint8_t UUID[16] = {0x17, 0xca, 0xf5, 0x86, 0x0f, 0x8d, 0x47, 0x8d, 0x88, 0x71, 0x06, 0xb5, 0xa0, 0x48, 0xb9, 0xcb};
  static constexpr uint8_t ID[4] = {0x00, 0x00, 0x00, 0x00};
}; 

struct Ctf_packet_context_bytes{
  static constexpr uint32_t length = 32;
  uint8_t timestamp_begin[8];
  uint8_t timestamp_end[8];
  uint8_t packet_size_length[8];
  uint8_t content_size_length[8];
};

// might as well make it one struct...
static constexpr uint8_t POWER_EVENT_ID[4] = {0xE2, 0x00, 0x00, 0x00}; //dont forget to write the id //cant put this in the struct...
struct Ctf_event_bytes{
  static constexpr uint32_t length = 92;
  uint8_t event_timestamp[8];
  uint8_t content[80];//sensor data payload for 16sensor x 5bytes [ID byte][data byte 1 to 4]
  uint8_t data_count = 0; //do not write, counts number of data points present in content
};

// BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB
//Buffer for one CTF packet and associated values 
uint8_t packetbuffer[1000];
int ctf_offset = 0;//offset for packetbuffer managed by ctf write and reset buffer.
int event_count = 0;
Ctf_event_bytes event_list[20]; // event reference list managed by ctf addevent and reset.
// BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB

#pragma endregion

#pragma region TCPvariables
// --------------------------------------------------------------------------
//  Configuration
// --------------------------------------------------------------------------

// NOTE: Not all the code here is needed

// The DHCP timeout, in milliseconds. Set to zero to not wait and
// instead rely on the listener to inform us of an address assignment.
constexpr uint32_t kDHCPTimeout = 15'000;  // 15 seconds

// The link timeout, in milliseconds. Set to zero to not wait and
// instead rely on the listener to inform us of a link.
constexpr uint32_t kLinkTimeout = 5'000;  // 5 seconds

constexpr uint16_t kServerPort = 80;

// Timeout for waiting for input from the client.
constexpr uint32_t kClientTimeout = 30'000;  // 5 seconds

// Timeout for waiting for a close from the client after a
// half close.
constexpr uint32_t kShutdownTimeout = 30'000;  // 30 seconds

// Set the static IP to something other than INADDR_NONE (all zeros)
// to not use DHCP. The values here are just examples.
IPAddress staticIP{100,100,100,100};//{192, 168, 1, 101};
IPAddress subnetMask{255, 255, 255, 0};
IPAddress gateway{192, 168, 1, 1};

// --------------------------------------------------------------------------
//  Types
// --------------------------------------------------------------------------

// Keeps track of state for a single client.
struct ClientState {
  ClientState(EthernetClient client)
      : client(std::move(client)) {}

  EthernetClient client;
  bool closed = false;

  // For timeouts.
  uint32_t lastRead = millis();  // Mark creation time

  // For half closed connections, after "Connection: close" was sent
  // and closeOutput() was called
  uint32_t closedTime = 0;    // When the output was shut down
  bool outputClosed = false;  // Whether the output was shut down

  // Parsing state
  bool emptyLine = false;
};
void processClientData(ClientState &state);
void requestTimeStamp(ClientState &state);
void processTimeStamp(ClientState &state);

// --------------------------------------------------------------------------
//  Program State
// --------------------------------------------------------------------------

// Keeps track of what and where belong to whom.
std::vector<ClientState> clients;

// The server.
EthernetServer server{kServerPort};

// --- 
// Additional stuff
// ---
uint32_t ipToKey(const IPAddress &ip) {
  return (uint32_t)ip[0] << 24 | (uint32_t)ip[1] << 16 |
         (uint32_t)ip[2] << 8 | (uint32_t)ip[3];
}

enum Role {
    Role_none = 0,
    Role_time_provider = 1,
    Role_logger = 2
};

// Roles map: IP (as 32-bit integer) -> role enum
std::map<uint32_t, int> clientRoles;

//keeping track if we have time provider
bool has_time_provider = false; //only set once time provider connects. does NOT reset if it disconnect

#pragma endregion

#pragma region timerHelpers

// const uint64_t NS_PER_OVERFLOW = 4294967296ULL * 1000ULL;
// uint32_t micros_times_overflown = 0;
// uint32_t micros_last_update_us;
void micros_init(uint32_t micros_now) {
  micros_last_update_us = micros_now;
  return;
}

uint64_t micros_get_nanos_now(uint32_t micros_now) {
  if (micros_now < micros_last_update_us){ //overflown
    micros_last_update_us = micros_now;
    micros_times_overflown += 1;
  }
  return NS_PER_OVERFLOW * micros_times_overflown + micros_now * 1000ULL;
}

#pragma endregion

#pragma region TCPhelpers
void printBytes(const void *ptr, size_t len) {
    const uint8_t *bytes = static_cast<const uint8_t*>(ptr);
    for (size_t i = 0; i < len; i++) {
        Serial.printf("%02X ", bytes[i]);
    }
    Serial.println();
}

bool initEthernet() {
  // DHCP
  if (staticIP == INADDR_NONE) {
    printf("Starting Ethernet with DHCP...\r\n");
    if (!Ethernet.begin()) {
      printf("Failed to start Ethernet\r\n");
      return false;
    }

    // We can choose not to wait and rely on the listener to tell us
    // when an address has been assigned
    if (kDHCPTimeout > 0) {
      printf("Waiting for IP address...\r\n");
      if (!Ethernet.waitForLocalIP(kDHCPTimeout)) {
        printf("No IP address yet\r\n");
        // We may still get an address later, after the timeout,
        // so continue instead of returning
      }
    }
  } else {
    // Static IP
    printf("Starting Ethernet with static IP...\r\n");
    if (!Ethernet.begin(staticIP, subnetMask, gateway)) {
      printf("Failed to start Ethernet\r\n");
      return false;
    }

    // When setting a static IP, the address is changed immediately,
    // but the link may not be up; optionally wait for the link here
    if (kLinkTimeout > 0) {
      printf("Waiting for link...\r\n");
      if (!Ethernet.waitForLink(kLinkTimeout)) {
        printf("No link yet\r\n");
        // We may still see a link later, after the timeout, so
        // continue instead of returning
      }
    }
  }

  return true;
}

void sendDummy (ClientState &state) { //this method is so dumb actually i should have just used two writes what was i thinking?!??!?
  //send buffered data
  uint8_t buffer[4] = {'a','b','c','d'};//dummy buffer
  uint32_t length = sizeof(buffer);
  uint8_t tcpdata_payload[length + 4];
  memcpy(tcpdata_payload, &length, 4);
  memcpy(tcpdata_payload + 4, &buffer, sizeof(buffer));

  state.client.write(tcpdata_payload, sizeof(tcpdata_payload));
  state.client.flush();
}

void sendData (ClientState &state) {
  uint32_t length = sizeof(buffer);
  uint8_t tcpdata_payload[length + 4];
  memcpy(tcpdata_payload, &length, 4);
  memcpy(tcpdata_payload + 4, &buffer, sizeof(buffer));

  state.client.write(tcpdata_payload, sizeof(tcpdata_payload));
  state.client.flush();
}

// uint64_t sync_begin_time_ns = 0;
// uint64_t sync_receive_time_ns = 0;
// uint64_t host_offset_ns = 0;

//jan 26
void requestTimeStamp(ClientState &state) { //call to update host time knowledge   
  uint8_t ts[8];
  uint64_t teensy_time = micros_get_nanos_now(micros());
  memcpy(ts, &teensy_time, 8);//remember to use reference when memcpy you doof
  // Send timestamp
  state.client.write(ts, 8);
  state.client.flush();
}

// before jan 26
// void requestTimeStamp(ClientState &state, uint32_t gpt1_tick) { //call to update host time knowledge   
//   uint8_t ts[8];
//   uint64_t teensy_time = getTeensyTimeNow(gpt1_tick);
//   memcpy(ts, &teensy_time, 8);//remember to use reference when memcpy you doof
//   // Send timestamp
//   state.client.write(ts, 8);
//   state.client.flush();
// }
// volatile struct time_adjusted_host { //oct 19 2025
//   uint64_t recvTime_GPT1; //recvd time @ teensy
//   uint64_t recvTime_host; //adjusted recvd time @ host 
//                           // Updated every time we call requestTimeStamp() but processing happens elsewhere
//                           // to access host time, call getHostTimeNow() 
// }

// uint64_t sync_begin_time_ns = 0;
// uint64_t sync_receive_time_ns = 0;
// uint64_t host_offset_ns = 0;

// jan 26
uint64_t getHostTimeNow(){
  return host_offset_ns + micros_get_nanos_now(micros());
}

// before jan 26
// uint64_t getHostTimeNow() { //returns host time now. obv. Host time unit is nS. 
//                             //If timeprovider doesnt exist, default behavior of this just returns GPT1 ticks converted to nanosecond.
//                             // since both recvTime is 0   
//   uint64_t now_ticks = getTeensyTimeNow(GPT1_CNT);
//   uint64_t ticks_since = now_ticks - time_adjusted_host.recvTime_GPT1;
//   uint64_t host_time_now = (ticks_since * 125 + 1) / 3 + time_adjusted_host.recvTime_host; //convert 24mhz to 1ghz time
//   return host_time_now; 
// }

void processClientData(ClientState &state) {
  // Accumulate incoming data into a buffer
  String incoming = "";

  while (true) {
    int avail = state.client.available();
    if (avail <= 0) {
      break;
    }

    state.lastRead = millis();
    int c = state.client.read();
    incoming += (char)c;

    if (c == '\n') {
      if (state.emptyLine) {
        break;
      }
      state.emptyLine = true;
    } else if (c != '\r') {
      state.emptyLine = false;
    }
  }

  if (incoming.length() == 0) {
    return;  // nothing new
  }

  IPAddress ip = state.client.remoteIP();
  uint32_t key = ipToKey(ip);



  if (clientRoles[key] == Role_none) {  //default case, no role
    // Role detection
    if (incoming.indexOf("time provider") >= 0) {
      clientRoles[key] = Role_time_provider;
      printf("Client %u.%u.%u.%u is TIME PROVIDER\n", ip[0], ip[1], ip[2], ip[3]);
      has_time_provider = true;
    } else if (incoming.indexOf("logger") >= 0) {
      clientRoles[key] = Role_logger;
      printf("Client %u.%u.%u.%u is LOGGER\n", ip[0], ip[1], ip[2], ip[3]);
      if(host_driven){
        printf("fetcher will wait for time provider");
      }
      else {
        printf("measurement should start now");
      }
      ctf_send_metadata(state);
    }
  }
  // uint64_t sync_begin_time_ns = 0;
// uint64_t sync_receive_time_ns = 0;
// uint64_t host_offset_ns = 0;
  else if (clientRoles[key] == Role_time_provider){
    if (incoming.length() >= 16) {
      const char *incomingBytes = incoming.c_str();
      uint64_t echoed, host_time_ns;
      memcpy(&echoed, incomingBytes, 8);
      memcpy(&host_time_ns, incomingBytes + 8, 8);
      uint64_t receive_time_ns = micros_get_nanos_now(micros());
      uint64_t delta = receive_time_ns - echoed;

      printf("Time sync reply from %u.%u.%u.%u\n", ip[0], ip[1], ip[2], ip[3]);
      printf("  Sent time: %llu\n", echoed);
      printf("  Recv time: %llu\n", receive_time_ns);
      printf("  Delta: %llu ticks\n", delta);
      printf("  Host time: %llu\n", host_time_ns);

      //logic for calculating relative time
        //delta time assumes the teensy is sending 24mhz RTC ticks in uint64_t format
        //Time_adjusted_host assumes 1 GHz or nanosecond precision host time in uint64_t format

      //DEBUG
      if (delta > 2000000) {// if delta is greater than 2000us something clearly went wrong 
        Serial.println("WARN: unusual roundtrip time. this timestamp will be dropped.");
        Serial.println(delta);
      }
      else if (host_time_ns < receive_time_ns) {
        Serial.println("WARN: host time < teensy time, time offset has overflown");
      }
      else {
        int64_t new_host_offset_ns = host_time_ns + delta/2 - receive_time_ns; // set global offset if delta within acceptable ranges
                                                                               // signed offset accomodate negative delta time due to PC sleep
        if (new_host_offset_ns > (host_offset_ns + 200000)){
          Serial.println("WARN: timeoffset has changed alot");
        }
        host_offset_ns = new_host_offset_ns;
        Serial.println("Host time offset ns changed: new offset:");
        Serial.println(host_offset_ns);
      }
    
      //convert delta from 24mhz to 1ghz to account for round trip time rounded up, then add to recvd host time.  
      // volatile struct time_adjusted_host { //oct 19 2025
      //   uint64_t recvTime_GPT1; //recvd time @ teensy
      //   uint64_t recvTime_host; //adjusted recvd time @ host 
      //                           // Updated every time we call requestTimeStamp() but processing happens elsewhere
      //                           // to access host time, call getHostTimeNow() 
      // }
    } else {
      //printf("No reply from time provider %u.%u.%u.%u\n",
      //       ip[0], ip[1], ip[2], ip[3]);
    }
  }
  else if (clientRoles[key] == Role_logger){ //logger 
    // do nothing because the logger doesnt send data to teensy
  } 
  else {
    printf("unknown role");
  }

  // Original HTTP response, pretty sure the timeprover thinks this is a timestamp somehow
  // printf("Sending to client: %u.%u.%u.%u\r\n", ip[0], ip[1], ip[2], ip[3]);
  // state.client.writeFully("HTTP/1.1 200 OK\r\n"
  //                         "Connection: close\r\n"
  //                         "Content-Type: text/plain\r\n"
  //                         "\r\n"
  //                         "Hello, Client!\r\n");
  // state.client.flush();

  //state.client.closeOutput();
  //state.closedTime = millis();
  //state.outputClosed = true;
}
#pragma endregion // end tcp helper and defs

#pragma region PowerFetcherDefsAndHelpers 
#define HOST_FEEDBACK_RATE_SECONDS        1
elapsedMillis sinceHostListen;
int led = 13;

typedef struct measurement {
  char id; // 1 byte
  byte power [2]; // 2 bytes
} measurement;


typedef struct measurementWithTime { //deprecated since sep 2025
  char id; // 1 byte
  byte power [2]; // 2 bytes
  unsigned int sampleTime; // 4 bytes, according to https://forum.pjrc.com/threads/36658-datatypes-bit-depth?p=114137&viewfull=1
}measurementWithTime;
unsigned int USB_write_struct(const measurementWithTime& value);
//unused 
template <typename T>
unsigned int USB_writeBytes(const T& value) {
  const byte * p = (const byte*) &value;
  unsigned int i;
  byte newlineMask = 0x00;
  for (i = 0; i < sizeof(value); i++) {
    if (*p == 0x0A) {
      newlineMask |= 1 << i;
      Serial.write(0x00); 
      p++;
    } else {
      Serial.write(*p++); 
    }
  }
  Serial.write(newlineMask);
  Serial.println();
  return i;
}


//write buffer is moved up to top because the TCP stuff need it too.
//const int BUFFER_MAX = 512;
//std::array<uint8_t, BUFFER_MAX> buffer;
//int bufferOffset = 0;
//deprecated
void writeBuffer(uint8_t writeByte){
  buffer[bufferOffset] = writeByte;
  bufferOffset += 1;
}
void sendBuffer (){
  Serial.write(buffer.data(), BUFFER_MAX);
  buffer.fill('\n');
  bufferOffset = 0;
}

//void writeCalibrationToBus(TwoWire wire, int INAs [16], int confs[16], int cals [16], bool online [16]) {
  void writeCalibration() {
    size_t n = sizeof(sensors) / sizeof (sensors[0]);
    for (int i = 0; i < n; ++i) {
      TwoWire* wire;
      if (sensors[i].bus == 0){
        wire = &Wire;
      }
      else if(sensors[i].bus == 1){
        wire = &Wire1;
      }
      else if(sensors[i].bus == 2){
        wire = &Wire2;
      }
      else {
        Serial.print("Sensor bus not correct check configuration.h");
        break;
      }
        //Write Configuration to INA226
      wire->beginTransmission(sensors[i].i2c_address);
      wire->write(CONFIGURATION_REGISTER);
      wire->write((sensors[i].config >> 8) & 0xFF);
      //Serial.print("writing confByte: "); Serial.println((sensors[i].config >> 8) & 0xFF, HEX);
      wire->write(sensors[i].config& 0xFF);
      //Serial.print("writing confByte 2: "); Serial.println(sensors[i].config& 0xFF, HEX);
      wire->endTransmission();
  
      //Write Calibration to INA226
      wire->beginTransmission(sensors[i].i2c_address);
      wire->write(CALIBRATION_REGISTER);
      wire->write((sensors[i].cal >> 8) & 0xFF); // this line send the LSB actually 
      //Serial.print("writing calByte: "); Serial.println((sensors[i].cal >> 8) & 0xFF, HEX);
      wire->write(sensors[i].cal & 0xFF); // so basically we wrote all the CAL values backwards. Aug22 2025
      //Serial.print("writing calByte 2: "); Serial.println(sensors[i].cal & 0xFF, HEX);
      wire->endTransmission();
  
      //Set INA226 Register-Pointer to the Power-Register
      wire->beginTransmission(sensors[i].i2c_address);
      //wire->write(BUS_VOLTAGE_REGISTER);
      wire->write(POWER_REGISTER);
      wire->endTransmission();

      // check if INA is online
      bool readOnline = isOnline(wire, sensors[i].i2c_address);
      sensors[i].is_online = readOnline;
      Serial.print("sensor "); Serial.print(sensors[i].id); Serial.print(" "); Serial.print(sensors[i].description); Serial.print(" ");
      if (readOnline){
        Serial.println(" ON ");
      }
      else {
        Serial.println(" OFF ");
      }
  }
}

bool isOnline(TwoWire* wire, int address) {
  wire->requestFrom(address, 2);
  if (wire->available() == 2) {
    int raw_data;
    raw_data = wire->read();
    raw_data = raw_data << 8;
    raw_data = raw_data + wire->read();
    //Serial.print(raw_data);
    return true;
  } else {
    //Something went wrong during the I2C-Communication
    return false;
  }
}

void printI2cConflict(){ // this is a static check (it analyzes the config, not the actual connections)
  bool conflictFound = false;
  for (int i = 0; i < 3; i ++){
    for (int j = 0x40; j <= 0x4F; j++){
      bool found = false;
      for (SensorConfig s : sensors){
        if (s.bus == i && s.i2c_address == j) {
          if (!found) {found = true;}
          else {conflictFound = true; Serial.print("I2c address conflict on bus "); Serial.print(i); Serial.print(" address"); Serial.print(j); Serial.println();}
        }
      }
    }
  }
  if (!conflictFound){
    Serial.println("No I2c address conflict all clear.");
  }
}
// this is unused, it is unclear if this works at all. i will not touch this.
int isAvailable(int address) {
  
  Wire.beginTransmission(address);
  Wire.write(MASK_ENABLE_REGISTER);
  Wire.endTransmission();
  
  Wire.requestFrom(address, 2);
  int result = -1;
  if (Wire.available() == 2) {
    //int raw_data;
    //raw_data = Wire.read();
    //raw_data = raw_data << 8;
    //raw_data = raw_data + Wire.read();
    //Serial.print(raw_data);

    // MISSING : read ready flag and return true if it is set.
    
    result = 1;
  } else {
    //Something went wrong during the I2C-Communication
    result = 0;
  }
    Wire.beginTransmission(address);
    Wire.write(POWER_REGISTER);
    Wire.endTransmission();
    return result;    
}

void write_found_IDs(){
  for (int i = 0; i < 16; i++) {
    if (ONLINE0[i] > 0 ) {
      Serial.write((byte) COMPONENTS0[i]);
    }
    if (ONLINE1[i] > 0 ) {
      Serial.write((byte) COMPONENTS1[i]);
    }
    if (ONLINE2[i] > 0 ) {
      Serial.write((byte) COMPONENTS2[i]);
    }
  }
  Serial.write((byte) 0);
}


void blink() {
  for (int i = 0; i < 3; i ++) {
    digitalWrite(led, LOW); 
    delay(300);
    digitalWrite(led, HIGH);
    delay(300); 
  }
}

void blink_short() {
  for (int i = 0; i < 3; i ++) {
    digitalWrite(led, LOW); 
    delay(75);
    digitalWrite(led, HIGH);
    delay(75); 
  }
}

int getNumberOnlineDevices() {
  int foundDevices = 0;
  size_t n = sizeof(sensors) / sizeof (sensors[0]);
  for (int i = 0; i < n; i++) {
    if (sensors[i].is_online > 0 ) {
      foundDevices ++;
    }
  }
  return foundDevices;
}
// deprecated
void addDevice(char componentIDs[16], int componentAddresses [16], int cals [16], int confs [16], const char deviceId, const int busAddress, const int cal, const int conf) {
  for (int i = 0; i < 16; i++) {
    if (componentAddresses[i] == NO_DEVICE) {
      // found position to insert new device
      componentAddresses[i] = busAddress;
      componentIDs[i] = deviceId;
      cals[i] = cal;
      confs[i] = conf;
      break;
    }
  }
}

void printBits(uint8_t b) {
  for (int i = 7; i >= 0; i--) {
    Serial.print((b >> i) & 1); // print each bit
  }
}

//process all sensors for power register
void poll_sensors_power() { //oct 19 2025
  byte raw_data1;
  byte raw_data2;
  String message;
  size_t n = sizeof(sensors) / sizeof (sensors[0]);
  
  float total = 0; //for display purpose only
  for (int i = 0; i < n; ++i) {
      TwoWire* wire;
      if (sensors[i].bus == 0){
        wire = &Wire;
      }
      else if(sensors[i].bus == 1){
        wire = &Wire1;
      }
      else if(sensors[i].bus == 2){
        wire = &Wire2;
      }
      else {
        Serial.print("Sensor bus not correct check configuration.h");
        break;
      }

    if (sensors[i].is_online == 1) {
      const char id = sensors[i].id;
      wire->requestFrom(sensors[i].i2c_address, 2);
      if (wire->available() == 2) {
        //oct19 now use host time. without host, default return gpt1 counter convrtd to nS.
        // jan 26: same stuff, except host logic is clearer: if no host, then offset is simply 0.
        uint64_t sampleTime = getHostTimeNow();
        raw_data1 = wire->read();
        raw_data2 = wire->read();
        //const measurementWithTime m = {id, {raw_data1, raw_data2}}; //old logic from serial days
        //USB_write_struct(m); // this will be replaced by CTF write soon probably.
        //write data directly to event_list: [id][b0][b1]
        uint16_t value_LE = (static_cast<uint16_t>(raw_data1) << 8) | raw_data2; 
        uint8_t cal_MSB = sensors[i].cal & 0xFF; 
        uint8_t cal_LSB = (sensors[i].cal >>8) & 0xFF; 
        uint16_t cal_int = (static_cast<uint16_t>(cal_LSB) << 8) | cal_MSB;//this conversion is neccessary
        float multiplier = 0.00512 / (sensors[i].rshunt * cal_int);
        //Serial.print("multi:"); Serial.print(sensors[i].rshunt);Serial.print("|");Serial.print(cal_int);Serial.print("|");
        //Serial.print(multiplier, 6);
        float value_adjusted = value_LE * multiplier * 25;
        total += value_adjusted;
        //DEBUGGGGGGGGGGGGGGGGGGGG enable uncomment       
        // if (sensors[i].id != '/'){
        //   Serial.print(sensors[i].id);
        //   Serial.print(" pwr(w)|");
        //   Serial.print(value_adjusted, 6); Serial.print(" ");
        //   Serial.print(multiplier, 6); Serial.print(" ");
        //   printBits(raw_data1); Serial.print(" ");
        //   printBits(raw_data2);
        //   Serial.println();
        // } //END DEBUUUUGGG
        uint8_t *value_bytes = reinterpret_cast<uint8_t*>(&value_adjusted);
        event_list[event_count].content[event_list[event_count].data_count] = static_cast<uint8_t>(id);
        event_list[event_count].content[event_list[event_count].data_count + 1] = value_bytes[0];
        event_list[event_count].content[event_list[event_count].data_count + 2] = value_bytes[1];
        event_list[event_count].content[event_list[event_count].data_count + 3] = value_bytes[2];
        event_list[event_count].content[event_list[event_count].data_count + 4] = value_bytes[3];
        // FYI the current is signed but power register is unsigned
        event_list[event_count].data_count += 5;
        memcpy(event_list[event_count].event_timestamp, &sampleTime, 8); //remember that time is 8 bytes 

      } else {
        //Something went wrong during the I2C-Communication
        uint64_t sampleTime = getHostTimeNow();
        const measurementWithTime m = {id, {66, 66}};
        //USB_write_struct(m); 
      }
    }
  }
  //more debug
  //Serial.print("Total pwr(w)|");
  //Serial.println(total, 6);
  //end debug
}

#pragma endregion //end power fetcher defs and helpers

#pragma region ctfHelpers
void ctf_reset_buffer (){
  //reset reference list
  //Serial.print("resetting buffer");
  //Serial.print("ec"); Serial.print(event_count);
  //Serial.print("c-off"); Serial.println(ctf_offset);
  memset(event_list, 0, sizeof(event_list));
  event_count = 0;
  ctf_offset = 0;
  //reset write buffer 
  memset(packetbuffer, 0, sizeof(packetbuffer));
  ctf_write_buffer(Ctf_packet_header_bytes::MAGIC, 4);
  ctf_write_buffer(Ctf_packet_header_bytes::UUID, 16);
  ctf_write_buffer(Ctf_packet_header_bytes::ID, 4);
  ctf_offset = Ctf_packet_header_bytes::length + Ctf_packet_context_bytes::length;
  //Serial.print(ctf_offset);
}
//write one byte array to buffer with no checks. handle with care.
void ctf_write_buffer(const void* src, size_t n) {
  memcpy(packetbuffer + ctf_offset, src, n);
  ctf_offset += n;
}// end write buffer 
bool ctf_full_buffer(){
  //Serial.print("is buffer full?");
  //Serial.print(ctf_offset + Ctf_event_bytes::length > sizeof(packetbuffer));
  //Serial.println(ctf_offset);
  return ( (ctf_offset + Ctf_event_bytes::length) > sizeof(packetbuffer));
}

void ctf_send_metadata (ClientState &state){
  uint32_t length = static_cast<uint32_t>(strlen(ctf_metadata));
  state.client.write( reinterpret_cast<const uint8_t*>(&length), 4); //compliance with preeixsting reading scheme
  state.client.write(reinterpret_cast<const uint8_t*>(ctf_metadata), strlen(ctf_metadata));
  state.client.flush();
  //Serial.print("debug: sent metadata");
  //Serial.print(ctf_metadata);
}

                      // should check before calling this if the buffer will be full.
void ctf_add_event(){// add one event with one set of observations to the packetbuffer.
                    // should also maintain an array of observations for easy access.
    // process bus now modified to use event_count to write to event reference list
  poll_sensors_power();
    // add binary of event fields to the packet buffer  
  ctf_write_buffer(POWER_EVENT_ID, sizeof(POWER_EVENT_ID));
  ctf_write_buffer(event_list[event_count].event_timestamp, sizeof(event_list[event_count].event_timestamp));
  ctf_write_buffer(event_list[event_count].content, sizeof(event_list[event_count].content));
    // increment offset accordingly (buffer offset managed by ctf_write_buffer)
  event_count += 1; 

} //end ctf add event

void ctf_send_packet(ClientState &state){ //build and send packet
  // Packet header: fixed
  // Write Packet context: since we are editing buffer we cannot use add event!!!
      // timestamp start = first element timestamp
      memcpy(packetbuffer + Ctf_packet_header_bytes::length, event_list[0].event_timestamp, sizeof(event_list[0].event_timestamp));
      // timestamp end = last element timestamp 
      memcpy(packetbuffer + Ctf_packet_header_bytes::length + sizeof(event_list[0].event_timestamp),
             event_list[event_count - 1].event_timestamp, 
             sizeof(event_list[event_count - 1].event_timestamp));
      // content size: constant size of packet header and context + (size of event header + content) * number of events
      uint64_t content_size = (static_cast<uint64_t>((Ctf_packet_header_bytes::length + Ctf_packet_context_bytes::length + event_count * Ctf_event_bytes::length) *8));
      memcpy(packetbuffer + Ctf_packet_header_bytes::length + sizeof(event_list[0].event_timestamp) + sizeof(event_list[event_count - 1].event_timestamp),
              &content_size, //same here
              8);
      // packet size: size of packetbUFFER actually because we changed receiver code to only save msg bytes
      //uint64_t packet_size = (static_cast<uint64_t>(sizeof(packetbuffer) * 8));
      uint64_t packet_size = content_size;
      //uint64_t packet_size = (static_cast<uint64_t>(2000 * 8));
      memcpy(packetbuffer + Ctf_packet_header_bytes::length + sizeof(event_list[0].event_timestamp) + sizeof(event_list[event_count - 1].event_timestamp) + 8,
              &packet_size, //*8 to convert from byte to bits ofc
              8);
      // unit for size is bits
  //send buffered data
  //uint32_t length = sizeof(packetbuffer); //changed to only send useful bytes
  uint32_t length = (uint32_t)content_size/8; //note that the unit of length is bytes but content size is bits. 
  state.client.write(reinterpret_cast<const uint8_t*>(&length), 4);
  state.client.write(packetbuffer, length);
  state.client.flush();
   
  //reset buffer in the end 
  ctf_reset_buffer();
} // end ctf send packet

void ctf_send_packet_headless(ClientState &state){ //build and send packet headlessly
//   struct Ctf_packet_header_bytes {
//   static constexpr uint32_t length = 24;
// }; 
//   struct Ctf_packet_context_bytes{
//    static constexpr uint32_t length = 32;
  //send buffered data, only send data. header and context is not sent
  uint64_t content_size = (uint64_t) event_count * Ctf_event_bytes::length;
  uint32_t start_byte = (Ctf_packet_header_bytes::length + Ctf_packet_context_bytes::length); //unit is bytes
  uint32_t length = (uint32_t)content_size; //note that the unit of length is bytes but content size is bytes. 

  state.client.write(reinterpret_cast<const uint8_t*>(&length), 4);
  state.client.write(packetbuffer + start_byte, length); //skipping start_byte number of bytes, doesnt send header, only content.
  state.client.flush();
  //Serial.printf("skipped %u bytes", start_byte);
  //Serial.printf("writing %u bytes", length);
   
  //reset buffer in the end 
  ctf_reset_buffer();
} // end ctf send packet

#pragma endregion //end region CTF defs and helpers

#define STR(x) #x
#define XSTR(x) STR(x)

// SETUP ---------------------------------------------------------------------
void setup() {

  micros_init(micros());

  if (CrashReport) {
    Serial.print(CrashReport); // This tells you EXACTLY why and where it crashed
  }

  Serial.begin(115200);
  while (!Serial && millis() < 4000) {
    // Wait for Serial
  }
  printf("Starting...\r\n");
#pragma region TCPsetup
  // Unlike the Arduino API (which you can still use), QNEthernet uses
  // the Teensy's internal MAC address by default, so we can retrieve
  // it here
  uint8_t mac[6];
  Ethernet.macAddress(mac);  // This is informative; it retrieves, not sets
  printf("MAC = %02x:%02x:%02x:%02x:%02x:%02x\r\n",
         mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);

  // Add listeners
  // It's important to add these before doing anything with Ethernet
  // so no events are missed.

  // Listen for link changes
  Ethernet.onLinkState([](bool state) {
    printf("[Ethernet] Link %s\r\n", state ? "ON" : "OFF");
  });

  // Listen for address changes
  Ethernet.onAddressChanged([]() {
    IPAddress ip = Ethernet.localIP();
    bool hasIP = (ip != INADDR_NONE);
    if (hasIP) {
      printf("[Ethernet] Address changed:\r\n");

      printf("    Local IP = %u.%u.%u.%u\r\n", ip[0], ip[1], ip[2], ip[3]);
      ip = Ethernet.subnetMask();
      printf("    Subnet   = %u.%u.%u.%u\r\n", ip[0], ip[1], ip[2], ip[3]);
      ip = Ethernet.gatewayIP();
      printf("    Gateway  = %u.%u.%u.%u\r\n", ip[0], ip[1], ip[2], ip[3]);
      ip = Ethernet.dnsServerIP();
      if (ip != INADDR_NONE) {  // May happen with static IP
        printf("    DNS      = %u.%u.%u.%u\r\n", ip[0], ip[1], ip[2], ip[3]);
      }
    } else {
      printf("[Ethernet] Address changed: No IP address\r\n");
    }
  });

  if (initEthernet()) {
    // Start the server
    printf("Starting server on port %u...", kServerPort);
    server.begin(kServerPort);
    printf("%s\r\n", (server) ? "Done." : "FAILED!");
  }
#pragma endregion

#pragma region TimeSetup
  //initiallize the GPT1 clock ===========================
  // Enable GPT module clock
  CCM_CCGR1 |= CCM_CCGR1_GPT(CCM_CCGR_ON);

  // Reset GPT and configure once
  GPT1_CR = 0;
  GPT1_CR = GPT_CR_SWR;                  // Software reset
  while (GPT1_CR & GPT_CR_SWR);          // Wait for reset

  GPT1_CR = GPT_CR_CLKSRC(1) | GPT_CR_ENMOD;  // Clock source: Peripheral Clock, Enable on reset
  GPT1_PR = 0;                                // No prescaler (24MHz clock)

  GPT1_CR |= GPT_CR_EN;                       // Start the timer
  //end of the GPT1 clock stuff ==========================
#pragma endregion

#pragma region powerFetcherSetup
  Wire.begin();
  Wire.setClock(BUS_CLOCK_FREQUENCY);
  
  Wire1.begin();
  Wire1.setClock(BUS_CLOCK_FREQUENCY);

  Wire2.begin();
  Wire2.setClock(BUS_CLOCK_FREQUENCY);
  //Serial.println("Running calibration for INAs.");
  
  printI2cConflict();

  writeCalibration();

  ctf_reset_buffer(); //required or the first send will not have header

  // // if bus-configuration contain integrity issues, crash out. 
  // for (int i = 0; i < sensors.length(); i++){
  //   if (sensors[i].description.indexOf(":") != -1 ||
  //       sensors[i].description.indexOf(",") != -1){
  //         Serial.println("@@@delimiter characters : or , in sensor description will break downstream applications.");
  //         int x = 1;
  //         assert (x == 10); //program will crash
  //       } 
  // } //implement later

  Serial.print("averaging setting: "); Serial.println(XSTR(CONFIG));

#pragma endregion

#pragma region bareCTFsetup
// struct barectf_default_ctx ctx; 
// std::array<uint8_t, 512> barectf_buffer; 
// struct barectf_platform_callbacks cbs; 
barectf_init(&ctx, barectf_buffer.data(), barectf_buffer.size(), cbs, nullptr);
if (barectf_is_tracing_enabled(&ctx)) {
  Serial.println("barectf enabled");
}
#pragma endregion

}



// MAIN LOOP --------------------------------------------------------------------- 
// this was using micros but it now use 24MHz GPT1 clock 
volatile uint64_t clock_get_timestamp = 0;
static uint64_t interval_get_timestamp = 48000000; // should be 1-2s or s * 24m ticks
volatile uint64_t clock_send_data = 0;
static uint64_t interval_send_data = 12000; // REAL SEND RATE 2kHz = 12000 ticks in 24MHz 
//static uint64_t interval_send_data = 24000000;/*testing send rate 1 per second*/
volatile uint64_t clock_still_alive = 0;
static uint64_t interval_still_alive = 48000000; //spin once every two seconds to show that it's still alive 
volatile uint64_t clock_do_other_thing = 0;
static uint64_t interval_do_other_thing = 1000;
//number for output batching 
const int MAX_BATCH = 3; //number of sensor batches per buffer send, max is like 50 measurements //deprecated
int bufferCount = 0;
bool logger_has_metadata = false;

void loop() {
  time_gpt1_tick = GPT1_CNT; //This is safe, but do not use raw GPT1_CNT value ever beside looping

  //so instead of doing this what we should be doing is this 
  // for every loop iteration, check if there are new clients 
    // the new client thing will decide if the new clients are time provider or loggers.
    // all other connections are to be dropped.

  // then check if preexisting clients are alive
  // every one second send them a packet to keep them alive 
  // if the time provider is alive, send time stamp once every X uS  
      // If the time provider dc, try to reconnect.
      // If the time provider hasnt been responding, throw error

  // if the logger is alive, send logs once every X uS 
      // if logger disconnected, try to reconnect 
      // If the logger is dead, there is nothing you can do anyways. 
#pragma region TCPlooping
  if ((time_gpt1_tick - clock_still_alive) > interval_still_alive){
    //Serial.print("_@_"); //if the snail is printing the server is alive ofc
    Serial.println("Device Time:");
    Serial.println(micros_get_nanos_now(micros()));
    clock_still_alive = time_gpt1_tick;
  }
  EthernetClient client = server.accept();
  if (client) {// New connection
    IPAddress ip = client.remoteIP();
    printf("Client connected: %u.%u.%u.%u\r\n", ip[0], ip[1], ip[2], ip[3]);
    clients.emplace_back(std::move(client));
    printf("Client count: %zu\r\n", clients.size());
  }

  // Process data from each client
  for (ClientState &state : clients) {  // Use a reference so we don't copy
    IPAddress ip = state.client.remoteIP();
    uint32_t key = ipToKey(ip);
    if (!state.client.connected()) {
      state.closed = true;
      continue;
    }

    // For now we are not gonna bother with checking if client need to be closed...
    // if (state.outputClosed) {
    //   if (millis() - state.closedTime >= kShutdownTimeout) {
    //     IPAddress ip = state.client.remoteIP();
    //     printf("Client shutdown timeout: %u.%u.%u.%u\r\n",
    //            ip[0], ip[1], ip[2], ip[3]);
    //     state.client.close();
    //     state.closed = true;
    //     continue;
    //   }
    // } else {
    //   if (millis() - state.lastRead >= kClientTimeout) {
    //     IPAddress ip = state.client.remoteIP();
    //     printf("Client timeout: %u.%u.%u.%u\r\n", ip[0], ip[1], ip[2], ip[3]);
    //     state.client.close();
    //     state.closed = true;
    //     continue;
    //   }
    // }
    if (clientRoles[key] == Role_time_provider 
        && (time_gpt1_tick - clock_get_timestamp) > interval_get_timestamp){ //do this or it wont handle rollover 
      requestTimeStamp(state);
      clock_get_timestamp = time_gpt1_tick;
      // code from timestamp processing
      // memcpy(&echoed, incomingBytes, 8);
      // memcpy(&secondary, incomingBytes + 8, 8);
      // uint64_t recvTime = getTeensyTimeNow(GPT1_CNT);
      // uint64_t delta = recvTime - echoed;
    }
    else if (clientRoles[key] == Role_logger 
        &&(time_gpt1_tick - clock_send_data) > interval_send_data
        && ( (!host_driven) || has_time_provider) ){
      //reading sensors and send data      
      ctf_add_event();
      if (ctf_full_buffer()){//buffer full send data
        //ctf_send_packet(state);
        ctf_send_packet_headless(state);
        //Serial.println("debug: ctf packet sent check for binary");
      } 
      clock_send_data = time_gpt1_tick; 
    }

    processClientData(state);
  } //end client loop
  // Clean up all the closed clients
  size_t size = clients.size();
  clients.erase(std::remove_if(clients.begin(), clients.end(),
                               [](const auto &state) { return state.closed; }),
                clients.end());
  if (clients.size() != size) {
    printf("New client count: %zu\r\n", clients.size());
  }
#pragma endregion //endregion TCP loop

#pragma region otherFetcherLooping

#pragma endregion //endregion fetcherlooping

}