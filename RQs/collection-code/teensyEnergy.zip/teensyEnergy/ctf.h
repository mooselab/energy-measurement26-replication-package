#define HEADER_SIZE  68
#define PACKET_SIZE  65536
#define PAYLOAD_SIZE PACKET_SIZE - HEADER_SIZE

 //ctf need a magic number to be sent every time
//hopefully we will make the sensor discovery automatic and dynamic but for now i am lzy

constexpr uint8_t CTF_MAGIC[4] { 
  0xC1, 0x1F, 0xFC, 0xC1
}; //CTF magic number is required.

constexpr uint8_t FETCHER_UUID[16] {
  0x17, 0xca, 0xf5, 0x86, 0x0f, 0x8d, 0x47, 0x8d,
  0x88, 0x71, 0x06, 0xb5, 0xa0, 0x48, 0xb9, 0xcb
};

constexpr uint8_t FETCHER_ID[4] {
  0x00, 0x00, 0x00, 0x00
};

constexpr uint8_t FETCHER_EVENT_ID[4] { // =226
  0xE2, 0x00, 0x00, 0x00
};

const char * ctf_metadata = "/* CTF 1.8 */\n"
  "typealias integer { size = 8; align = 8; signed = false; base = 10; } := uint8_t;\n"
  "typealias integer { size = 16; align = 8; signed = false; base = 10; } := uint16_t;\n"
  "typealias integer { size = 32; align = 8; signed = false; base = 10; } := uint32_t;\n"
  "typealias integer { size = 64; align = 8; signed = false; base = 10; } := uint64_t;\n"
  "typealias floating_point { align = 8; exp_dig = 8; mant_dig = 24; byte_order = le;} := float32_t;\n"
  "enum source_name : uint8_t {\"unknown-\" = 0...88, \"EPS1\" = 89, \"EPS2\" = 90, \"unknown+\" = 91...255,};\n" //ideally assigned dynamically
  "env {domain = \"PowerTrace25\"; tracer = \"PowerTrace25\"; source_count = 16; source_names = \"8:EPS1,9:EPS2\";};\n"    //ideally assigned dynamically also
  "trace { major = 1; minor = 8; byte_order = le; uuid = \"2a6422d0-6cee-11e0-8c08-cb07d7b3a564\"; packet.header := struct { uint32_t magic; uint8_t uuid[16]; uint32_t stream_id; }; };\n"
  "clock { name = hybrid_clock_1ghz; freq = 1000000000; precision = 1; description = \"Hybrid clock generated from host timestamp adjusted with tcp roundtrip time\"; absolute = FALSE; };\n"
  "typealias integer { size = 64; align = 8; signed = false; map = clock.hybrid_clock_1ghz.value; } := timestamp_t;\n"
  "stream { id = 0; event.header := struct { uint32_t id; timestamp_t timestamp; }; packet.context := struct { timestamp_t timestamp_begin; timestamp_t timestamp_end; uint64_t content_size; uint64_t packet_size; }; };\n"
  "event { name = Pwrsensor_event; id = 226; stream_id = 0; fields := struct { struct { enum source_name id; float32_t value; } sensors[16]; }; };\n"
;


